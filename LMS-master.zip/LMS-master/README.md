# Django LCMS
An integrated Content management with a Learning management system
The Learning Management system done in django and helps Instructors,students and course authors comminicate effectively through virtualization of the actual classrom environment
Instructors enrol students to various courses,Students access learning materials,Study courses,take tests online and submit assignments to their respective instructors for marking if needed.
The instructors track records,Update course content,and analyse the results and post them back to the students.
The system integrates a chat bot assistant which an onsite support team to help anyone inquiring about anything in the course of the study



#Add to models
#courseDuration

#COurse Module
this basically handles the content of the courses

#ADMIN MOdule
this manages ser actions and their permissinos.